import Heading from '../components/Heading';
import InfoBox from '../components/InfoBox';
import usePageTitle from '../hooks/usePageTitle';

const principles = [
  { title: 'Our Mission', text: 'To make study materials easier to reach by connecting graduating students with the students who need their notes and textbooks.' },
  { title: 'Our Vision', text: 'A campus community where no student is held back by the cost or availability of course materials.' },
  { title: 'Our Objectives', text: 'Reduce what students spend on books, reduce waste, and encourage students to support one another.' },
];

function About() {
  usePageTitle('About');

  return (
    <>
      <section className="page-top">
        <Heading plain="About" highlight="Campus Bookshop" />
        <div className="about-grid">
          <img src="/images/about.svg" alt="Books being passed from one student to another" />
          <div className="about-text">
            <h3>What we do</h3>
            <p>
              Campus Bookshop is an online service for a higher institution. Graduating students list the notes and
              textbooks they no longer need, and current students browse the list and request what they want.
              Every item is offered in one of three ways: sold at a student-friendly price, shared for free, or
              lent for a fixed number of days.
            </p>
            <h3>Our background</h3>
            <p>
              Each year, graduating students leave campus with shelves of books and notes that were expensive to
              buy and are still useful. At the same time, new students struggle to afford the same materials.
              Campus Bookshop was created to connect the two groups in one simple place.
            </p>
          </div>
        </div>
      </section>

      <section>
        <Heading plain="What we" highlight="stand for" />
        <div className="box-container">
          {principles.map((item) => (
            <InfoBox key={item.title} title={item.title} text={item.text} />
          ))}
        </div>
      </section>
    </>
  );
}

export default About;
