import { useState, useEffect } from 'react';

// Custom hook: works like useState but keeps the value in localStorage.
export default function useLocalStorage(key, initialValue) {
  const [value, setValue] = useState(() => {
    try {
      const stored = window.localStorage.getItem(key);
      return stored ? JSON.parse(stored) : initialValue;
    } catch {
      return initialValue;
    }
  });

  useEffect(() => {
    try {
      window.localStorage.setItem(key, JSON.stringify(value));
    } catch {
      // storage unavailable (e.g. private mode) - the app still works in memory
    }
  }, [key, value]);

  return [value, setValue];
}
