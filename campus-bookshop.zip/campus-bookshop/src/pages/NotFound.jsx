import { Link } from 'react-router-dom';
import usePageTitle from '../hooks/usePageTitle';

function NotFound() {
  usePageTitle('Page not found');
  return (
    <section className="page-top center">
      <h2 className="heading">Page <span>not found</span></h2>
      <p className="page-intro">Sorry, that page does not exist.</p>
      <Link to="/" className="btn btn-filled">Back to Home</Link>
    </section>
  );
}

export default NotFound;
