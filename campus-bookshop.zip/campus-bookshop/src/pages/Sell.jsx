import { useState } from 'react';
import { Link } from 'react-router-dom';
import Heading from '../components/Heading';
import FormField from '../components/FormField';
import { useListings } from '../context/ListingsContext';
import { CATEGORIES, CONDITIONS, LEVELS, TYPES, CURRENCY } from '../data/listings';
import { isValidEmail } from '../utils/validation';
import usePageTitle from '../hooks/usePageTitle';

const emptyForm = {
  type: 'sell',
  title: '',
  author: '',
  category: '',
  level: '',
  condition: '',
  price: '',
  loanDays: '',
  description: '',
  seller: '',
  department: '',
  email: '',
};

function validate(values) {
  const errors = {};
  if (!values.title.trim()) errors.title = 'Please enter the title.';
  if (!values.category) errors.category = 'Please choose a category.';
  if (!values.level) errors.level = 'Please choose a level.';
  if (!values.condition) errors.condition = 'Please choose the condition.';

  if (values.type === 'sell') {
    if (values.price === '' || Number(values.price) <= 0) errors.price = 'Enter a price greater than 0.';
  }
  if (values.type === 'borrow') {
    const days = Number(values.loanDays);
    if (!days || days < 1 || days > 120) errors.loanDays = 'Enter a loan period between 1 and 120 days.';
  }

  if (values.description.trim().length < 10) errors.description = 'Please add a short description (at least 10 characters).';
  if (!values.seller.trim()) errors.seller = 'Please enter your name.';
  if (!values.department.trim()) errors.department = 'Please enter your department.';
  if (!values.email.trim()) errors.email = 'Please enter your email address.';
  else if (!isValidEmail(values.email)) errors.email = 'Please enter a valid email address.';
  return errors;
}

function Sell() {
  usePageTitle('Post an Item');
  const { addListing } = useListings();

  const [values, setValues] = useState(emptyForm);
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setValues({ ...values, [name]: value });
    if (errors[name]) setErrors({ ...errors, [name]: '' });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const found = validate(values);
    setErrors(found);
    if (Object.keys(found).length > 0) return;

    addListing({
      type: values.type,
      title: values.title.trim(),
      author: values.author.trim() || 'Not stated',
      category: values.category,
      level: values.level,
      condition: values.condition,
      price: values.type === 'sell' ? Number(values.price) : 0,
      loanDays: values.type === 'borrow' ? Number(values.loanDays) : undefined,
      description: values.description.trim(),
      seller: values.seller.trim(),
      department: values.department.trim(),
    });
    setSubmitted(true);
    setValues(emptyForm);
  };

  if (submitted) {
    return (
      <section className="page-top">
        <div className="message success big">
          <h3>Your item has been posted!</h3>
          <p>It now appears in the Browse page. You can remove it from there at any time.</p>
          <div className="btn-row center">
            <Link to="/browse" className="btn btn-filled">View in Browse</Link>
            <button type="button" className="btn" onClick={() => setSubmitted(false)}>Post another</button>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="page-top">
      <Heading plain="Post an" highlight="item" />
      <p className="page-intro">Graduating? List your notes or textbooks and choose how you want to pass them on.</p>

      <form className="form" onSubmit={handleSubmit} noValidate>
        <fieldset>
          <legend>How do you want to pass it on?</legend>
          <div className="radio-row">
            {TYPES.map((t) => (
              <label key={t.value} className={values.type === t.value ? 'radio active' : 'radio'}>
                <input type="radio" name="type" value={t.value} checked={values.type === t.value} onChange={handleChange} />
                {t.label}
              </label>
            ))}
          </div>
        </fieldset>

        <FormField label="Title *" id="title" error={errors.title}>
          <input id="title" name="title" type="text" value={values.title} onChange={handleChange} placeholder="e.g. Introduction to Programming" />
        </FormField>

        <FormField label="Author or type (optional)" id="author">
          <input id="author" name="author" type="text" value={values.author} onChange={handleChange} placeholder="e.g. Course textbook, handwritten notes" />
        </FormField>

        <div className="form-row">
          <FormField label="Category *" id="category" error={errors.category}>
            <select id="category" name="category" value={values.category} onChange={handleChange}>
              <option value="">Choose...</option>
              {CATEGORIES.map((c) => <option key={c.name} value={c.name}>{c.name}</option>)}
            </select>
          </FormField>

          <FormField label="Level *" id="level" error={errors.level}>
            <select id="level" name="level" value={values.level} onChange={handleChange}>
              <option value="">Choose...</option>
              {LEVELS.map((l) => <option key={l} value={l}>{l}</option>)}
            </select>
          </FormField>

          <FormField label="Condition *" id="condition" error={errors.condition}>
            <select id="condition" name="condition" value={values.condition} onChange={handleChange}>
              <option value="">Choose...</option>
              {CONDITIONS.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </FormField>
        </div>

        {values.type === 'sell' && (
          <FormField label={`Price (${CURRENCY}) *`} id="price" error={errors.price}>
            <input id="price" name="price" type="number" min="0" value={values.price} onChange={handleChange} placeholder="e.g. 3000" />
          </FormField>
        )}

        {values.type === 'borrow' && (
          <FormField label="Loan period (days) *" id="loanDays" error={errors.loanDays}>
            <input id="loanDays" name="loanDays" type="number" min="1" max="120" value={values.loanDays} onChange={handleChange} placeholder="e.g. 14" />
          </FormField>
        )}

        <FormField label="Description *" id="description" error={errors.description}>
          <textarea id="description" name="description" rows="4" value={values.description} onChange={handleChange} placeholder="Describe what is included and anything the next student should know." />
        </FormField>

        <div className="form-row">
          <FormField label="Your name *" id="seller" error={errors.seller}>
            <input id="seller" name="seller" type="text" value={values.seller} onChange={handleChange} />
          </FormField>
          <FormField label="Department *" id="department" error={errors.department}>
            <input id="department" name="department" type="text" value={values.department} onChange={handleChange} />
          </FormField>
        </div>

        <FormField label="Email address *" id="email" error={errors.email}>
          <input id="email" name="email" type="email" value={values.email} onChange={handleChange} placeholder="you@example.com" />
        </FormField>

        {Object.keys(errors).some((k) => errors[k]) && (
          <p className="message error-box" role="alert">Please fix the highlighted fields and try again.</p>
        )}

        <button type="submit" className="btn btn-filled">Post item</button>
      </form>
    </section>
  );
}

export default Sell;
