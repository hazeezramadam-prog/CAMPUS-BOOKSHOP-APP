import { useListings } from '../context/ListingsContext';
import { CURRENCY, TYPES, getCover } from '../data/listings';

function priceLabel(listing) {
  if (listing.type === 'sell') return `${CURRENCY}${Number(listing.price).toLocaleString()}`;
  if (listing.type === 'share') return 'Free';
  return `${listing.loanDays} day loan`;
}

// Reusable product card. The parent passes one listing in through props.
function ListingCard({ listing }) {
  const { saved, requested, toggleSaved, toggleRequested, removeListing } = useListings();

  const isSaved = saved.includes(listing.id);
  const isRequested = requested.includes(listing.id);
  const typeInfo = TYPES.find((t) => t.value === listing.type);

  return (
    <article className="box listing-card">
      <span className={`tag tag-${listing.type}`}>{typeInfo.label}</span>

      <button
        type="button"
        className={isSaved ? 'save-btn saved' : 'save-btn'}
        onClick={() => toggleSaved(listing.id)}
        aria-pressed={isSaved}
        aria-label={isSaved ? 'Remove from saved' : 'Save this item'}
      >
        {isSaved ? '♥' : '♡'}
      </button>

      <img src={getCover(listing.category)} alt={`${listing.category} cover`} />

      <h3>{listing.title}</h3>
      <p className="meta">
        {listing.category} &bull; {listing.level}
      </p>
      <p className="meta">
        {listing.author} &bull; {listing.condition}
      </p>
      <p className="description">{listing.description}</p>
      <div className="price">{priceLabel(listing)}</div>
      <p className="seller">
        Posted by {listing.seller} ({listing.department})
      </p>

      <button
        type="button"
        className={isRequested ? 'btn btn-filled' : 'btn'}
        onClick={() => toggleRequested(listing.id)}
      >
        {isRequested ? 'Requested ✓ (tap to cancel)' : typeInfo.verb}
      </button>

      {listing.isMine && (
        <button type="button" className="link-btn" onClick={() => removeListing(listing.id)}>
          Remove my listing
        </button>
      )}
    </article>
  );
}

export default ListingCard;
