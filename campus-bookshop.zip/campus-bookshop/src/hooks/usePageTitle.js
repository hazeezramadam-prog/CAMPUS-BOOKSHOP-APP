import { useEffect } from 'react';

// Custom hook: sets the browser tab title for each page.
export default function usePageTitle(title) {
  useEffect(() => {
    document.title = title ? `${title} | Campus Bookshop` : 'Campus Bookshop';
  }, [title]);
}
