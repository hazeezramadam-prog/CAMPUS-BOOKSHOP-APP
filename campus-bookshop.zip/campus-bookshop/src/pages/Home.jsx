import { useState } from 'react';
import { Link } from 'react-router-dom';
import Heading from '../components/Heading';
import InfoBox from '../components/InfoBox';
import ListingCard from '../components/ListingCard';
import { useListings } from '../context/ListingsContext';
import { TYPES } from '../data/listings';
import usePageTitle from '../hooks/usePageTitle';

const steps = {
  sell: ['Post your item with a title, condition and price.', 'Current students browse and send a request.', 'Agree a meeting point on campus and get paid.'],
  share: ['Post your notes or books and mark them as free.', 'A student who needs them sends a request.', 'Hand them over and help a coursemate succeed.'],
  borrow: ['Post your item and choose how many days it can be borrowed.', 'A student requests the loan.', 'Meet on campus, lend it out and collect it when the time is up.'],
};

function Home() {
  usePageTitle('Home');
  const { listings } = useListings();
  const [mode, setMode] = useState('sell'); // interactive element: tabs

  const featured = listings.slice(0, 3);

  return (
    <>
      <section className="home">
        <div className="content">
          <h1>
            Welcome to Campus <span>Bookshop</span>
          </h1>
          <p>
            Campus Bookshop helps graduating students sell, share or lend their old notes and textbooks to current
            students, so useful study materials never end up forgotten on a shelf.
          </p>
          <div className="btn-row">
            <Link to="/browse" className="btn btn-filled">Browse Materials</Link>
            <Link to="/sell" className="btn">Post an Item</Link>
          </div>
          <p className="count">{listings.length} items available right now</p>
        </div>
        <img src="/images/hero.svg" alt="A stack of textbooks topped with a graduation cap" className="hero-img" />
      </section>

      <section className="how">
        <Heading plain="How it" highlight="works" />
        <div className="tabs" role="tablist">
          {TYPES.map((t) => (
            <button
              key={t.value}
              type="button"
              role="tab"
              aria-selected={mode === t.value}
              className={mode === t.value ? 'tab active' : 'tab'}
              onClick={() => setMode(t.value)}
            >
              {t.label}
            </button>
          ))}
        </div>
        <div className="tab-panel">
          <p className="tab-intro">{TYPES.find((t) => t.value === mode).description}</p>
          <ol>
            {steps[mode].map((step, index) => (
              <li key={index}>{step}</li>
            ))}
          </ol>
        </div>
      </section>

      <section>
        <Heading plain="Why use" highlight="Campus Bookshop" />
        <div className="box-container">
          <InfoBox image="/images/icon-sell.svg" title="Affordable for students" text="Used materials cost far less than new copies, and graduates earn something back." />
          <InfoBox image="/images/icon-share.svg" title="Pass knowledge forward" text="Share notes and textbooks for free and help the next set of students." />
          <InfoBox image="/images/icon-borrow.svg" title="Borrow when you need it" text="Need a book for a single semester? Borrow it for a few days or weeks." />
        </div>
      </section>

      <section>
        <Heading plain="Latest" highlight="items" />
        <div className="box-container">
          {featured.map((item) => (
            <ListingCard key={item.id} listing={item} />
          ))}
        </div>
        <div className="center">
          <Link to="/browse" className="btn">See all items</Link>
        </div>
      </section>
    </>
  );
}

export default Home;
