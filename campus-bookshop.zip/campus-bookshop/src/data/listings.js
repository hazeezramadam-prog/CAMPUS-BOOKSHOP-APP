// Sample data used to demonstrate the application.
// All listings, names and contact details below are sample content.

export const CURRENCY = '₦';

export const CATEGORIES = [
  { name: 'Computing', image: '/images/cover-computing.svg' },
  { name: 'Engineering', image: '/images/cover-engineering.svg' },
  { name: 'Business', image: '/images/cover-business.svg' },
  { name: 'Law', image: '/images/cover-law.svg' },
  { name: 'Sciences', image: '/images/cover-sciences.svg' },
  { name: 'Humanities', image: '/images/cover-humanities.svg' },
];

export const LEVELS = ['100 Level', '200 Level', '300 Level', '400 Level', 'Postgraduate'];
export const CONDITIONS = ['Like new', 'Good', 'Fair'];

export const TYPES = [
  { value: 'sell', label: 'Sell', verb: 'Buy', description: 'Set a price and sell to a current student.' },
  { value: 'share', label: 'Share', verb: 'Claim', description: 'Give your materials away for free.' },
  { value: 'borrow', label: 'Borrow', verb: 'Borrow', description: 'Lend them out for a set number of days.' },
];

export const seedListings = [
  {
    id: 's1', title: 'Introduction to Programming', author: 'Course textbook', category: 'Computing',
    level: '100 Level', type: 'sell', condition: 'Good', price: 4500,
    description: 'Clean copy with light highlighting in the first five chapters.',
    seller: 'Amina B.', department: 'Computer Science',
  },
  {
    id: 's2', title: 'Data Structures Lecture Notes', author: 'Handwritten notes', category: 'Computing',
    level: '200 Level', type: 'share', condition: 'Good', price: 0,
    description: 'Complete semester notes with worked examples and past exam tips.',
    seller: 'Tunde O.', department: 'Computer Science',
  },
  {
    id: 's3', title: 'Engineering Mathematics', author: 'Course textbook', category: 'Engineering',
    level: '200 Level', type: 'borrow', condition: 'Fair', price: 0, loanDays: 14,
    description: 'Well-used but complete. Some pencil notes in the margins.',
    seller: 'Chidi E.', department: 'Mechanical Engineering',
  },
  {
    id: 's4', title: 'Principles of Accounting', author: 'Course textbook', category: 'Business',
    level: '100 Level', type: 'sell', condition: 'Like new', price: 6000,
    description: 'Hardly used. Includes the practice workbook.',
    seller: 'Grace A.', department: 'Accounting',
  },
  {
    id: 's5', title: 'Introduction to Law Course Pack', author: 'Course material', category: 'Law',
    level: '100 Level', type: 'share', condition: 'Good', price: 0,
    description: 'Printed course pack with summaries of the main cases.',
    seller: 'Ibrahim S.', department: 'Law',
  },
  {
    id: 's6', title: 'Organic Chemistry Notes', author: 'Handwritten notes', category: 'Sciences',
    level: '300 Level', type: 'sell', condition: 'Good', price: 2500,
    description: 'Neat colour-coded notes covering reaction mechanisms.',
    seller: 'Zainab K.', department: 'Chemistry',
  },
  {
    id: 's7', title: 'Research Methods Guide', author: 'Course textbook', category: 'Humanities',
    level: 'Postgraduate', type: 'borrow', condition: 'Like new', price: 0, loanDays: 21,
    description: 'Useful for dissertation planning. Please return in the same condition.',
    seller: 'Daniel F.', department: 'Sociology',
  },
  {
    id: 's8', title: 'Software Engineering Textbook', author: 'Course textbook', category: 'Computing',
    level: '300 Level', type: 'sell', condition: 'Good', price: 5500,
    description: 'Includes sticky tabs on the key chapters for exam revision.',
    seller: 'Ruth M.', department: 'Software Engineering',
  },
  {
    id: 's9', title: 'Business Communication Notes', author: 'Typed notes', category: 'Business',
    level: '200 Level', type: 'share', condition: 'Like new', price: 0,
    description: 'Printed and bound, with sample essays and presentation tips.',
    seller: 'Samuel N.', department: 'Business Administration',
  },
];

// Looks up the cover image for a category name.
export function getCover(category) {
  const found = CATEGORIES.find((c) => c.name === category);
  return found ? found.image : '/images/cover-humanities.svg';
}
