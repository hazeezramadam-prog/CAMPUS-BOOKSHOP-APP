import { createContext, useContext } from 'react';
import useLocalStorage from '../hooks/useLocalStorage';
import { seedListings } from '../data/listings';

const ListingsContext = createContext(null);

export function ListingsProvider({ children }) {
  // Only the listings posted by the user are stored; sample data is merged in.
  const [myListings, setMyListings] = useLocalStorage('campusbookshop-my-listings', []);
  const [saved, setSaved] = useLocalStorage('campusbookshop-saved', []);
  const [requested, setRequested] = useLocalStorage('campusbookshop-requested', []);

  const listings = [...myListings, ...seedListings];

  const addListing = (data) => {
    const newListing = {
      ...data,
      id: `u${Date.now()}`,
      isMine: true,
    };
    setMyListings([newListing, ...myListings]);
  };

  const removeListing = (id) => {
    setMyListings(myListings.filter((item) => item.id !== id));
    setSaved(saved.filter((savedId) => savedId !== id));
    setRequested(requested.filter((reqId) => reqId !== id));
  };

  const toggleInList = (list, setList, id) => {
    setList(list.includes(id) ? list.filter((x) => x !== id) : [...list, id]);
  };

  const value = {
    listings,
    saved,
    requested,
    addListing,
    removeListing,
    toggleSaved: (id) => toggleInList(saved, setSaved, id),
    toggleRequested: (id) => toggleInList(requested, setRequested, id),
  };

  return <ListingsContext.Provider value={value}>{children}</ListingsContext.Provider>;
}

// Custom hook so components can simply call useListings().
export function useListings() {
  return useContext(ListingsContext);
}
