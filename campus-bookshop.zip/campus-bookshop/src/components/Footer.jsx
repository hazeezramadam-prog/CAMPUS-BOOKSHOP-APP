import { Link } from 'react-router-dom';

function Footer() {
  return (
    <footer className="footer">
      <div className="box-container">
        <div className="box">
          <h3>Campus <span>Bookshop</span></h3>
          <p>A simple place for graduating students to pass their notes and textbooks on to the next set of students.</p>
        </div>

        <div className="box">
          <h3>Quick Links</h3>
          <Link to="/" className="links">Home</Link>
          <Link to="/about" className="links">About</Link>
          <Link to="/browse" className="links">Browse</Link>
          <Link to="/sell" className="links">Post an Item</Link>
          <Link to="/contact" className="links">Contact</Link>
        </div>

        <div className="box">
          <h3>Contact</h3>
          <p>Email: support@campusbookshop.example</p>
          <p>Phone: +234 800 000 0000</p>
          <p>(Sample details for demonstration)</p>
        </div>
      </div>

      <div className="credit">Built with React JS | &copy; {new Date().getFullYear()} Campus Bookshop</div>
    </footer>
  );
}

export default Footer;
