import { useState } from 'react';
import Heading from '../components/Heading';
import FormField from '../components/FormField';
import { isValidEmail } from '../utils/validation';
import usePageTitle from '../hooks/usePageTitle';

const emptyForm = { name: '', email: '', subject: '', message: '' };

function validate(values) {
  const errors = {};
  if (!values.name.trim()) errors.name = 'Please enter your full name.';
  else if (values.name.trim().length < 2) errors.name = 'Your name is too short.';

  if (!values.email.trim()) errors.email = 'Please enter your email address.';
  else if (!isValidEmail(values.email)) errors.email = 'Please enter a valid email address.';

  if (!values.subject.trim()) errors.subject = 'Please enter a subject.';

  if (!values.message.trim()) errors.message = 'Please enter your message.';
  else if (values.message.trim().length < 10) errors.message = 'Your message should be at least 10 characters.';
  return errors;
}

function Contact() {
  usePageTitle('Contact');

  const [values, setValues] = useState(emptyForm);
  const [errors, setErrors] = useState({});
  const [success, setSuccess] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setValues({ ...values, [name]: value });
    if (errors[name]) setErrors({ ...errors, [name]: '' });
    if (success) setSuccess(false);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const found = validate(values);
    setErrors(found);
    if (Object.keys(found).length === 0) {
      setSuccess(true);
      setValues(emptyForm);
    }
  };

  return (
    <section className="page-top">
      <Heading plain="Contact" highlight="us" />

      <div className="contact-grid">
        <div className="contact-info">
          <h3>Get in touch</h3>
          <p>Questions about a listing, or need help posting? Send us a message and we will reply as soon as we can.</p>
          <p><strong>Email:</strong> support@campusbookshop.example</p>
          <p><strong>Telephone:</strong> +234 800 000 0000</p>
          <p><strong>Office:</strong> Student Affairs Building, Main Campus</p>
          <p><strong>Hours:</strong> Monday to Friday, 9am - 4pm</p>
          <p className="note">These are sample contact details for demonstration.</p>
        </div>

        <form className="form" onSubmit={handleSubmit} noValidate>
          {success && (
            <p className="message success" role="status">
              Thank you! Your message has been sent. We will get back to you soon.
            </p>
          )}

          <FormField label="Full name *" id="name" error={errors.name}>
            <input id="name" name="name" type="text" value={values.name} onChange={handleChange} />
          </FormField>

          <FormField label="Email address *" id="email" error={errors.email}>
            <input id="email" name="email" type="email" value={values.email} onChange={handleChange} />
          </FormField>

          <FormField label="Subject *" id="subject" error={errors.subject}>
            <input id="subject" name="subject" type="text" value={values.subject} onChange={handleChange} />
          </FormField>

          <FormField label="Message *" id="message" error={errors.message}>
            <textarea id="message" name="message" rows="5" value={values.message} onChange={handleChange} />
          </FormField>

          <button type="submit" className="btn btn-filled">Send message</button>
        </form>
      </div>
    </section>
  );
}

export default Contact;
