// Reusable card used for features, mission/vision and steps. Props: image, title, text.
function InfoBox({ image, title, text }) {
  return (
    <div className="box info-box">
      {image && <img src={image} alt="" />}
      <h3>{title}</h3>
      <p>{text}</p>
    </div>
  );
}

export default InfoBox;
