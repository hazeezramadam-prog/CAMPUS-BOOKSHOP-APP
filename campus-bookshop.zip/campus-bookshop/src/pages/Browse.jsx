import { useState } from 'react';
import Heading from '../components/Heading';
import ListingCard from '../components/ListingCard';
import { useListings } from '../context/ListingsContext';
import { CATEGORIES, TYPES } from '../data/listings';
import usePageTitle from '../hooks/usePageTitle';

function Browse() {
  usePageTitle('Browse');
  const { listings, saved } = useListings();

  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');
  const [category, setCategory] = useState('all');
  const [savedOnly, setSavedOnly] = useState(false);

  const results = listings.filter((item) => {
    const text = `${item.title} ${item.author} ${item.department}`.toLowerCase();
    const matchesSearch = text.includes(search.trim().toLowerCase());
    const matchesType = typeFilter === 'all' || item.type === typeFilter;
    const matchesCategory = category === 'all' || item.category === category;
    const matchesSaved = !savedOnly || saved.includes(item.id);
    return matchesSearch && matchesType && matchesCategory && matchesSaved;
  });

  const clearFilters = () => {
    setSearch('');
    setTypeFilter('all');
    setCategory('all');
    setSavedOnly(false);
  };

  return (
    <section className="page-top">
      <Heading plain="Browse" highlight="materials" />

      <div className="filters">
        <input
          type="search"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search by title, author or department..."
          aria-label="Search materials"
        />

        <select value={category} onChange={(e) => setCategory(e.target.value)} aria-label="Filter by category">
          <option value="all">All categories</option>
          {CATEGORIES.map((c) => (
            <option key={c.name} value={c.name}>{c.name}</option>
          ))}
        </select>
      </div>

      <div className="tabs">
        <button type="button" className={typeFilter === 'all' ? 'tab active' : 'tab'} onClick={() => setTypeFilter('all')}>
          All
        </button>
        {TYPES.map((t) => (
          <button
            key={t.value}
            type="button"
            className={typeFilter === t.value ? 'tab active' : 'tab'}
            onClick={() => setTypeFilter(t.value)}
          >
            {t.label}
          </button>
        ))}
        <button type="button" className={savedOnly ? 'tab active' : 'tab'} onClick={() => setSavedOnly(!savedOnly)}>
          ♥ Saved ({saved.length})
        </button>
      </div>

      <p className="result-count" aria-live="polite">
        Showing {results.length} of {listings.length} items
      </p>

      {results.length > 0 ? (
        <div className="box-container">
          {results.map((item) => (
            <ListingCard key={item.id} listing={item} />
          ))}
        </div>
      ) : (
        <div className="empty">
          <p>No items match your search.</p>
          <button type="button" className="btn" onClick={clearFilters}>Clear filters</button>
        </div>
      )}
    </section>
  );
}

export default Browse;
