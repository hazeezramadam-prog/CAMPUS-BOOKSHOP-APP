# Campus Bookshop

## Project Description

Campus Bookshop is a responsive web application built with React JS for a higher institution. It lets **graduating students sell, share or lend their old notes and textbooks to current students**.

Every item is posted in one of three ways:

- **Sell** - set a price.
- **Share** - give it away for free.
- **Borrow** - lend it for a set number of days.

Pages: **Home**, **About**, **Browse** (products), **Post an Item** and **Contact**.

> All listings, names, emails and phone numbers in the app are sample data for demonstration.
> The currency symbol is set in one place: `CURRENCY` in `src/data/listings.js`.

## Technologies Used

- React JS (functional components and hooks)
- React Router
- Vite
- JavaScript (ES6+), HTML, CSS (Flexbox, Grid, media queries)
- Browser Local Storage

## Features

- Home page with welcome message, images, navigation and interactive "How it works" tabs
- About page with background, mission, vision and objectives
- Browse page with search, category filter, Sell/Share/Borrow filter, save (favourite) and request buttons
- Post an Item form with validation - new listings appear on the Browse page
- Contact page with contact details and a validated form
- Data is kept in Local Storage (saved items, requests, your own listings)
- Responsive layout for phones, tablets and desktops

## React Concepts Implemented

| Concept | Where it is used |
| --- | --- |
| Functional components, import/export | everything in `src/components` and `src/pages` |
| JSX, `className`, JS expressions in JSX | all components |
| Props | `ListingCard`, `InfoBox`, `Heading`, `FormField` |
| `.map()` and `.filter()` | listings on Home and Browse, form options, nav links |
| `useState` | menu toggle, tabs, filters, form values, errors |
| Event handling (`onClick`, `onChange`, `onSubmit`) | buttons, inputs, both forms |
| Controlled forms and validation | `pages/Sell.jsx`, `pages/Contact.jsx` |
| React Router (`Routes`, `Route`, `NavLink`, `Link`) | `App.jsx`, `Header.jsx` |
| `useEffect` | `ScrollToTop`, `usePageTitle`, `useLocalStorage` |
| `useContext` | `context/ListingsContext.jsx` |
| Custom hooks | `useLocalStorage`, `usePageTitle`, `useListings` |
| Conditional rendering | success/error messages, empty results, price/loan fields |

## Project Structure

```
campus-bookshop/
├── public/            static files (images, _redirects)
├── src/
│   ├── components/    reusable components
│   ├── context/       shared listings state (useContext)
│   ├── data/          sample listings and constants
│   ├── hooks/         custom hooks
│   ├── pages/         Home, About, Browse, Sell, Contact, NotFound
│   ├── utils/         validation helper
│   ├── App.jsx        routes and layout
│   ├── main.jsx       entry file
│   └── index.css      all styles (external stylesheet)
├── index.html
├── package.json
└── README.md
```

## Installation

1. Clone or download the repository.
2. Open the project folder in VS Code.
3. Run: `npm install`

## Running the Application

```
npm run dev
```

Open the local address shown in the terminal (usually http://localhost:5173).

To create a production build: `npm run build` (output goes to `dist/`).

## Deployment

- **Netlify:** build command `npm run build`, publish directory `dist`. The file `public/_redirects` makes page refreshes work with React Router.
- **Vercel:** framework preset "Vite". The file `vercel.json` handles page refreshes.

## Author

Add your name, GitHub username and live URL here before submitting.
