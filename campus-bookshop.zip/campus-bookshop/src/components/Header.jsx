import { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';

const links = [
  { to: '/', label: 'Home' },
  { to: '/about', label: 'About' },
  { to: '/browse', label: 'Browse' },
  { to: '/sell', label: 'Post an Item' },
  { to: '/contact', label: 'Contact' },
];

function Header() {
  const [menuOpen, setMenuOpen] = useState(false);

  const closeMenu = () => setMenuOpen(false);

  return (
    <header className="header">
      <Link to="/" className="logo" onClick={closeMenu}>
        <img src="/images/favicon.svg" alt="" className="logo-img" />
        <span className="logo-text">Campus <em>Bookshop</em></span>
      </Link>

      <nav className={menuOpen ? 'navbar active' : 'navbar'} aria-label="Main navigation">
        {links.map((link) => (
          <NavLink key={link.to} to={link.to} end={link.to === '/'} onClick={closeMenu}>
            {link.label}
          </NavLink>
        ))}
      </nav>

      <button
        type="button"
        id="menu-btn"
        className="menu-btn"
        aria-label="Toggle menu"
        aria-expanded={menuOpen}
        onClick={() => setMenuOpen(!menuOpen)}
      >
        {menuOpen ? '✕' : '☰'}
      </button>
    </header>
  );
}

export default Header;
