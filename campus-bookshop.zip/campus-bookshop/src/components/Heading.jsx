// Reusable section heading that matches the old project's orange ribbon style.
function Heading({ plain, highlight }) {
  return (
    <h2 className="heading">
      {plain} <span>{highlight}</span>
    </h2>
  );
}

export default Heading;
