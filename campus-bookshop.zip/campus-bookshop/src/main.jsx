import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App.jsx';
import { ListingsProvider } from './context/ListingsContext.jsx';
import './index.css';

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <BrowserRouter>
      <ListingsProvider>
        <App />
      </ListingsProvider>
    </BrowserRouter>
  </StrictMode>
);
